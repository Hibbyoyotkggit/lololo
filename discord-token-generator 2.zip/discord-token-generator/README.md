Working September 2022!
# INFO
- This is a Simple Discord Token Generator which creates unverified/verified discord accounts 
- These accounts are good for member boosting for your server or for raiding
- Uses HCAPTCHA Bypass
- Accounts created are unlocked!



# USAGE
- Download [Python](https://www.python.org/ftp/python/3.9.13/python-3.9.13-amd64.exe)
- Open console in token generator folder and run `pip install -r requirements.txt`
- add proxies in ./data/proxies.txt (username:password@ip:port / ip:port)
- add api key and select captcha type/password on ./data/config.json
- move avatars to ./data/avatars
- Open console in token generator folder and run `python main.py`
- Enjoy!
